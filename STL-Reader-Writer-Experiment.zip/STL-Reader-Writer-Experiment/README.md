# Geometric-Operations
Reading, writing .STL, .OFF, .OBJ files in binary or ascii format, and performing geometric operations on them 
